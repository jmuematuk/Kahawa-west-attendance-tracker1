/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { Department, ShiftType, ClockAction, User } from "./src/types";

const PORT = 3000;
const DB_PATH = path.join(process.cwd(), "database.json");

// Helper structure for database schema
interface DBState {
  users: User[];
  authStore: Record<string, { passwordHash: string; role: "employee" | "admin" }>;
  logs: ClockAction[];
}

// Initial Pre-Seeded Supermarket Accounts and Attendance Records
const DEFAULT_STATE: DBState = {
  users: [
    {
      id: "KW-8849-CS",
      fullName: "Mary Wangari",
      department: Department.CASHIER,
      shift: ShiftType.MORNING,
      role: "employee",
      isActive: false,
      createdAt: "2026-05-15T08:00:00Z"
    },
    {
      id: "KW-7512-PR",
      fullName: "Grace Mwangi",
      department: Department.PRODUCE,
      shift: ShiftType.MORNING,
      role: "employee",
      isActive: true,
      createdAt: "2026-05-16T08:00:00Z"
    },
    {
      id: "KW-2244-SE",
      fullName: "David Kiprop",
      department: Department.SECURITY,
      shift: ShiftType.AFTERNOON,
      role: "employee",
      isActive: false,
      createdAt: "2026-05-17T08:00:00Z"
    },
    {
      id: "KW-1120-IN",
      fullName: "John Omwamba",
      department: Department.INVENTORY,
      shift: ShiftType.NIGHT,
      role: "employee",
      isActive: false,
      createdAt: "2026-05-18T08:00:00Z"
    },
    {
      id: "kahawa_manager",
      fullName: "Supervisor Max",
      department: Department.ADMIN,
      shift: ShiftType.MORNING,
      role: "admin",
      isActive: false,
      createdAt: "2026-05-10T08:00:00Z"
    }
  ],
  authStore: {
    "KW-8849-CS": { passwordHash: "password123", role: "employee" },
    "KW-7512-PR": { passwordHash: "password123", role: "employee" },
    "KW-2244-SE": { passwordHash: "password123", role: "employee" },
    "KW-1120-IN": { passwordHash: "password123", role: "employee" },
    "kahawa_manager": { passwordHash: "manager123", role: "admin" }
  },
  logs: [
    {
      id: "LOG-101",
      userId: "KW-8849-CS",
      userName: "Mary Wangari",
      userDepartment: Department.CASHIER,
      actionType: "CLOCK_IN",
      timestamp: "2026-06-01T05:50:00Z", // Compliant check-in for 06:00 shift
      location: "Checkout Till #1",
      healthDeclarationAccepted: true,
      notes: "Starting cashier tills. Checking registers.",
      complianceChecked: true,
      complianceStatus: "compliant",
      complianceFlags: []
    },
    {
      id: "LOG-102",
      userId: "KW-8849-CS",
      userName: "Mary Wangari",
      userDepartment: Department.CASHIER,
      actionType: "CLOCK_OUT",
      timestamp: "2026-06-01T14:02:00Z",
      location: "Checkout Till #1",
      healthDeclarationAccepted: true,
      notes: "Shift complete. Till balanced and locked.",
      complianceChecked: true,
      complianceStatus: "compliant",
      complianceFlags: []
    },
    {
      id: "LOG-103",
      userId: "KW-7512-PR",
      userName: "Grace Mwangi",
      userDepartment: Department.PRODUCE,
      actionType: "CLOCK_IN",
      timestamp: "2026-06-01T06:40:00Z", // Late (shift starts 6am)
      location: "Bakery Ovens & Display",
      healthDeclarationAccepted: true,
      notes: "Traffic jam near Central Gg Road.",
      complianceChecked: true,
      complianceStatus: "non-compliant",
      complianceFlags: ["LATE_ARRIVAL"]
    },
    {
      id: "LOG-104",
      userId: "KW-2244-SE",
      userName: "David Kiprop",
      userDepartment: Department.SECURITY,
      actionType: "CLOCK_IN",
      timestamp: "2026-06-01T13:50:00Z", // Compliant morning shift
      location: "CCTV Monitoring Headquarters",
      healthDeclarationAccepted: true,
      notes: "Daily inspections completed.",
      complianceChecked: true,
      complianceStatus: "compliant",
      complianceFlags: []
    }
  ]
};

// Initialize file database
function loadDB(): DBState {
  if (fs.existsSync(DB_PATH)) {
    try {
      const content = fs.readFileSync(DB_PATH, "utf-8");
      return JSON.parse(content);
    } catch (err) {
      console.error("Failed to parse database.json, reverting to defaults", err);
      return DEFAULT_STATE;
    }
  }
  saveDB(DEFAULT_STATE);
  return DEFAULT_STATE;
}

function saveDB(state: DBState) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(state, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save database.json", err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Database Memory Initialization
  let db = loadDB();

  // AUTH API endpoints
  // Employee Register
  app.post("/api/auth/employee/register", (req, res) => {
    const { id, fullName, department, shift, password } = req.body;
    
    if (!id || !fullName || !department || !shift || !password) {
      return res.status(400).json({ message: "All employee registration details required" });
    }

    if (db.authStore[id]) {
      return res.status(400).json({ message: "An employee with this ID is already registered" });
    }

    const newUser: User = {
      id,
      fullName,
      department,
      shift,
      role: "employee",
      isActive: false,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    db.authStore[id] = { passwordHash: password, role: "employee" };
    saveDB(db);

    res.json({ message: "Employee registered successfully", user: newUser });
  });

  // Employee Login
  app.post("/api/auth/employee/login", (req, res) => {
    const { id, password } = req.body;
    if (!id || !password) {
      return res.status(400).json({ message: "Employee ID and password are required" });
    }

    const user = db.users.find(u => u.id === id && u.role === "employee");
    const auth = db.authStore[id];

    if (!user || !auth || auth.passwordHash !== password) {
      return res.status(401).json({ message: "Invalid Employee credentials" });
    }

    res.json({
      message: "Authorized",
      user,
      token: `emp-token-${id}-${Math.random().toString(36).substring(2)}`
    });
  });

  // Admin Register (Manager Gate)
  app.post("/api/auth/admin/register", (req, res) => {
    const { username, fullName, password, adminCode } = req.body;

    if (!username || !fullName || !password || !adminCode) {
      return res.status(400).json({ message: "All administrative registration fields required" });
    }

    // Checking our standard setup authorization code
    if (adminCode !== "admin123") {
      return res.status(403).json({ message: "Invalid supervisor bypass clearance code" });
    }

    if (db.authStore[username]) {
      return res.status(400).json({ message: "A manager with this admin username already exists" });
    }

    const newAdmin: User = {
      id: username,
      fullName,
      department: Department.ADMIN,
      shift: ShiftType.MORNING,
      role: "admin",
      isActive: false,
      createdAt: new Date().toISOString()
    };

    db.users.push(newAdmin);
    db.authStore[username] = { passwordHash: password, role: "admin" };
    saveDB(db);

    res.json({ message: "Administrator authorized successfully", user: newAdmin });
  });

  // Admin Login
  app.post("/api/auth/admin/login", (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: "Admin username and password are required" });
    }

    const user = db.users.find(u => u.id === username && u.role === "admin");
    const auth = db.authStore[username];

    if (!user || !auth || auth.passwordHash !== password) {
      return res.status(401).json({ message: "Access Denied: Invalid Management credentials" });
    }

    res.json({
      message: "Authorized",
      user,
      token: `manager-token-${username}-${Math.random().toString(36).substring(2)}`
    });
  });


  // CLOCK LOGS API
  // Get active status for employee
  app.get("/api/clock/status/:userId", (req, res) => {
    const { userId } = req.params;
    const user = db.users.find(u => u.id === userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Get all matching logs today for this user
    const userHistory = db.logs.filter(l => l.userId === userId);
    
    // Determine clocked in/out status
    const lastAction = userHistory.length > 0 ? userHistory[userHistory.length - 1] : null;
    const isClockedIn = lastAction ? lastAction.actionType === "CLOCK_IN" : false;

    res.json({
      isClockedIn,
      lastAction,
      history: userHistory.slice().reverse() // Return in reverse chronological order for timeline
    });
  });

  // Submit Clock In / OUT
  app.post("/api/clock/action", (req, res) => {
    const { userId, actionType, location, notes, healthDeclarationAccepted } = req.body;

    if (!userId || !actionType || !location) {
      return res.status(400).json({ message: "Incomplete activity log fields" });
    }

    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(444).json({ message: "Employee not found in registry" });
    }

    // Determine compliance
    const timestampNow = new Date();
    const complianceFlags: string[] = [];

    if (actionType === "CLOCK_IN") {
      // 1. Uniform/Safety checks
      if (!healthDeclarationAccepted) {
        complianceFlags.push("SAFETY_CHECK_BYPASS");
      }

      // 2. Late Arrival Compliance Check
      // Morning standard start is 06:00. Late if clocked in after 06:15
      // Afternoon standard start is 14:00. Late if clocked in after 14:15
      // Night standard start is 22:00. Late if clocked in after 22:15
      const currentHours = timestampNow.getHours();
      const currentMinutes = timestampNow.getMinutes();

      if (user.shift === ShiftType.MORNING) {
        if (currentHours > 6 || (currentHours === 6 && currentMinutes > 15)) {
          complianceFlags.push("LATE_ARRIVAL");
        }
      } else if (user.shift === ShiftType.AFTERNOON) {
        if (currentHours > 14 || (currentHours === 14 && currentMinutes > 15)) {
          complianceFlags.push("LATE_ARRIVAL");
        }
      } else if (user.shift === ShiftType.NIGHT) {
        if (currentHours > 22 || (currentHours === 22 && currentMinutes > 15)) {
          complianceFlags.push("LATE_ARRIVAL");
        }
      }
    } else {
      // CLOCK OUT
      // Overtime Compliance check: Check if their original CLOCK_IN was more than 8 hours ago
      const userHistory = db.logs.filter(l => l.userId === userId);
      const lastIn = userHistory.length > 0 ? userHistory[userHistory.length - 1] : null;
      if (lastIn && lastIn.actionType === "CLOCK_IN") {
        const inTime = new Date(lastIn.timestamp).getTime();
        const hrsDiff = (timestampNow.getTime() - inTime) / (1000 * 60 * 60);
        if (hrsDiff > 8) {
          complianceFlags.push("SHIFT_OVERTIME");
        }
      }
    }

    const complianceStatus = complianceFlags.length > 0 ? "non-compliant" : "compliant";

    const newLog: ClockAction = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      userName: user.fullName,
      userDepartment: user.department,
      actionType,
      timestamp: timestampNow.toISOString(),
      location,
      healthDeclarationAccepted: !!healthDeclarationAccepted,
      notes: notes || "",
      complianceChecked: true,
      complianceStatus,
      complianceFlags
    };

    // Update active state in master registry
    user.isActive = (actionType === "CLOCK_IN");

    db.logs.push(newLog);
    saveDB(db);

    res.json({ message: "Action logged", user, log: newLog });
  });


  // ADMIN SUPERVISOR ROUTING
  // Get all activities logs
  app.get("/api/admin/logs", (req, res) => {
    // Return all logged entries, reverse chronological
    res.json({ logs: db.logs.slice().reverse() });
  });

  // Get list of employees
  app.get("/api/admin/users", (req, res) => {
    res.json({ users: db.users });
  });

  // Reset database state to pristine pre-seeds
  app.post("/api/admin/reset", (req, res) => {
    // Restore default
    db = JSON.parse(JSON.stringify(DEFAULT_STATE));
    saveDB(db);
    res.json({ message: "Database state restored successfully" });
  });

  // Simulation suite for real-time compliance evaluation
  app.post("/api/admin/simulate", (req, res) => {
    const { simType } = req.body;

    if (simType === "COMPLIANT") {
      const u = db.users.find(x => x.id === "KW-8849-CS") || db.users[0];
      const isCurrentlyIn = u.isActive;

      const actType = isCurrentlyIn ? "CLOCK_OUT" : "CLOCK_IN";
      u.isActive = !isCurrentlyIn;
      
      const simulatedTime = new Date();
      // Force hours to compliant level if checking in (6:00 shift clocking in at 05:48 AM)
      if (actType === "CLOCK_IN") {
        simulatedTime.setHours(5, 48, 0);
      }

      const simLog: ClockAction = {
        id: `LOG-SIM-${Date.now()}`,
        userId: u.id,
        userName: u.fullName,
        userDepartment: u.department,
        actionType: actType,
        timestamp: simulatedTime.toISOString(),
        location: actType === "CLOCK_IN" ? "Checkout Till #3" : "Checkout Till #3",
        healthDeclarationAccepted: true,
        notes: actType === "CLOCK_IN" ? "[Simulated] Automated shift login protocol." : "[Simulated] Off shift handovers done.",
        complianceChecked: true,
        complianceStatus: "compliant",
        complianceFlags: []
      };

      db.logs.push(simLog);
      saveDB(db);
      return res.json({ message: `Simulated a compliant ${actType} audit for ${u.fullName}` });
    }

    if (simType === "LATE") {
      // Simulate John clocking in at 08:35 AM (Morning shift late)
      const u = db.users.find(x => x.id === "KW-1120-IN") || db.users[2];
      u.isActive = true;
      
      const lateTime = new Date();
      lateTime.setHours(8, 35, 12);

      const simLog: ClockAction = {
        id: `LOG-SIM-${Date.now()}`,
        userId: u.id,
        userName: u.fullName,
        userDepartment: u.department,
        actionType: "CLOCK_IN",
        timestamp: lateTime.toISOString(),
        location: "Dry Goods Isle 4-8",
        healthDeclarationAccepted: true,
        notes: "[Simulated] Heavy commuter delays. Checked in late.",
        complianceChecked: true,
        complianceStatus: "non-compliant",
        complianceFlags: ["LATE_ARRIVAL"]
      };

      db.logs.push(simLog);
      saveDB(db);
      return res.json({ message: `Simulated a late check-in infraction for ${u.fullName}` });
    }

    if (simType === "OVERTIME") {
      // Simulate David clocking out with 11.5 hours of work
      const u = db.users.find(x => x.id === "KW-2244-SE") || db.users[3];
      u.isActive = false;

      const simLog: ClockAction = {
        id: `LOG-SIM-${Date.now()}`,
        userId: u.id,
        userName: u.fullName,
        userDepartment: u.department,
        actionType: "CLOCK_OUT",
        timestamp: new Date().toISOString(),
        location: "Staff Entry Inspection Gate",
        healthDeclarationAccepted: true,
        notes: "[Simulated] Extended floor audit covering security emergency.",
        complianceChecked: true,
        complianceStatus: "non-compliant",
        complianceFlags: ["SHIFT_OVERTIME"]
      };

      db.logs.push(simLog);
      saveDB(db);
      return res.json({ message: `Simulated overtime limit infraction log for ${u.fullName}` });
    }

    res.status(400).json({ message: "Invalid simulate token type" });
  });


  // Vite integration middleware or static folder
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server launched on port ${PORT}`);
  });
}

startServer();
