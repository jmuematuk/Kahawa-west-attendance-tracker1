/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Clock, CheckSquare, AlertTriangle, Play, Square, MapPin, ClipboardList, RefreshCw, Calendar, Sparkles } from "lucide-react";
import { User, ClockAction, Department } from "../types";

interface ClockPanelProps {
  user: User;
  token: string;
  onActivityLogged: () => void;
}

export function ClockPanel({ user, token, onActivityLogged }: ClockPanelProps) {
  const [time, setTime] = useState(new Date());
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [lastAction, setLastAction] = useState<ClockAction | null>(null);
  const [history, setHistory] = useState<ClockAction[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Compliance checkboxes
  const [decls, setDecls] = useState({
    sanitization: false,
    fitForWork: false,
    uniformStandard: false
  });

  // Entry Station
  const [location, setLocation] = useState("Checkout Counter Till 1");
  const [notes, setNotes] = useState("");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Tick the clock every second
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch current status
  const fetchStatus = async () => {
    try {
      const res = await fetch(`/api/clock/status/${user.id}`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setIsClockedIn(data.isClockedIn);
        setLastAction(data.lastAction);
        setHistory(data.history || []);
      }
    } catch (err) {
      console.error("Error fetching state:", err);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, [user.id, token]);

  const handleClockAction = async (type: "CLOCK_IN" | "CLOCK_OUT") => {
    setStatusMessage(null);
    
    // Check constraints if clocking in
    if (type === "CLOCK_IN") {
      if (!decls.sanitization || !decls.fitForWork || !decls.uniformStandard) {
        setStatusMessage("❌ Compliance Warning: You must affirm all safety, medical, and dress-code rules before clocking in.");
        return;
      }
    }

    setLoading(true);

    try {
      const res = await fetch("/api/clock/action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          userId: user.id,
          actionType: type,
          location,
          notes,
          healthDeclarationAccepted: type === "CLOCK_IN" // accepted if they checked the boxes
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || "Attendance punch failed");
      }

      setStatusMessage(`✅ ${type === "CLOCK_IN" ? "Clocked In successfully!" : "Clocked Out successfully!"}`);
      setIsClockedIn(type === "CLOCK_IN");
      setNotes("");
      
      // Reset compliance check boxes
      setDecls({
        sanitization: false,
        fitForWork: false,
        uniformStandard: false
      });

      // Synchronize dashboard
      fetchStatus();
      onActivityLogged();
    } catch (err: any) {
      setStatusMessage(`❌ Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Human-formatted timing elements
  const formatTime = (d: Date) => {
    return d.toLocaleTimeString("en-US", { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const formatDate = (d: Date) => {
    return d.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  // Station lists relative to department
  const getStationsForDept = (dept: Department) => {
    switch (dept) {
      case Department.CASHIER:
        return ["Checkout Till #1", "Checkout Till #2", "Checkout Till #3", "Express Lane #1 (Fast Check)", "Bulk / Wholesale Counter"];
      case Department.PRODUCE:
        return ["Fresh Fruits & Veg Section", "Bakery Ovens & Display", "Butchery Cold Room", "Deli Hot Bar Stand"];
      case Department.INVENTORY:
        return ["Main Loading Cargo Dock", "Dry Goods Isle 4-8", "Cosmetics Display Shelving", "FMCG Storage Room B"];
      case Department.SECURITY:
        return ["CCTV Monitoring Headquarters", "Kahawa West Front Entrance Ground Monitor", "Staff Entry Inspection Gate", "Parking Area Patrol"];
      case Department.CUSTOMER_SERVICE:
        return ["Supermarket Reception Desk", "Returns & Exchanges Counter", "Loyalty Card enrollment center"];
      default:
        return ["Admin Central Offices", "Manager Desks Control Room", "Vault Cashier Cage"];
    }
  };

  const stations = getStationsForDept(user.department);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* LEFT COLUMN: Time Punch Card */}
      <div className="lg:col-span-7 space-y-6">
        
        {/* Real-time Giant Clock Face */}
        <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 overflow-hidden text-center relative p-8">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-blue-500 via-indigo-600 to-violet-500" />
          
          <div className="flex justify-between items-center mb-6">
            <span className={`px-3 py-1 rounded-full text-[11px] font-mono font-bold uppercase tracking-widest border ${
              isClockedIn 
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                : "bg-amber-500/10 text-amber-400 border-amber-500/20"
            }`}>
              Status: {isClockedIn ? "🟢 Clocked In" : "⚪ Off Shift"}
            </span>
            <div className="flex items-center space-x-1.5 text-xs text-zinc-400 font-mono">
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
              <span>{formatDate(time)}</span>
            </div>
          </div>

          {/* Dynamic clock displays */}
          <div className="py-6">
            <h1 className="text-5xl font-mono font-bold tracking-widest text-white tabular-nums">
              {formatTime(time)}
            </h1>
            <p className="text-xs text-zinc-500 uppercase tracking-widest mt-2">
              Kahawa West Store Central Time (EAT/UCT+3)
            </p>
          </div>

          <div className="border-t border-white/10 mt-4 pt-6 grid grid-cols-2 gap-4 text-left">
            <div className="bg-[#161619] p-3.5 rounded-xl border border-white/5">
              <p className="text-[10px] uppercase font-mono font-semibold text-blue-400">Assignee</p>
              <p className="text-sm font-bold text-white shrink-0 truncate mt-0.5">{user.fullName}</p>
              <p className="text-[11px] text-zinc-400 mt-0.5">{user.department}</p>
            </div>
            <div className="bg-[#161619] p-3.5 rounded-xl border border-white/5">
              <p className="text-[10px] uppercase font-mono font-semibold text-blue-400">Assigned Shift</p>
              <p className="text-xs font-bold text-white py-0.5 mt-0.5 truncate">{user.shift}</p>
              <p className="text-[10px] text-zinc-500 font-mono">KW Staff Register ID: {user.id}</p>
            </div>
          </div>
        </div>

        {/* Policy Verification & Actions */}
        <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 p-6">
          <h3 className="text-base font-bold text-white border-b border-white/10 pb-3 flex items-center space-x-2">
            <ClipboardList className="w-5 h-5 text-blue-400" />
            <span className="font-sans">Shift Register Guard Protocol</span>
          </h3>

          {statusMessage && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-3 rounded-lg text-xs font-medium my-4 border ${
                statusMessage.includes("❌") 
                  ? "bg-red-950/40 text-red-300 border-red-900/30" 
                  : "bg-emerald-950/40 text-emerald-300 border-emerald-900/30"
              }`}
            >
              {statusMessage}
            </motion.div>
          )}

          {/* Form Settings */}
          <div className="space-y-4 mt-4">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1 flex items-center space-x-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-400" />
                <span>Store Station Guard assignment</span>
              </label>
              <select
                disabled={isClockedIn}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full text-xs p-2.5 border border-white/10 rounded-lg bg-zinc-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                {stations.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              {isClockedIn && (
                <p className="text-[10px] text-zinc-500 mt-1 italic">
                  Station cannot be changed after you punch in. To switch, check out and punch back in.
                </p>
              )}
            </div>

            {/* Shift notes */}
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1 flex items-center space-x-1 font-sans">
                <span>Supermarket Shift Notes (Optional)</span>
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Write any handovers, equipment safety status or register notes here..."
                className="w-full text-xs p-2.5 border border-white/10 rounded-lg bg-zinc-900 text-white placeholder-zinc-650 focus:outline-none focus:ring-2 focus:ring-blue-600 min-h-[60px]"
              />
            </div>

            {/* Compliance checklist, required only if clocked OUT */}
            {!isClockedIn && (
              <div className="p-4 bg-[#1B1B1F] rounded-xl border border-white/5 space-y-3">
                <div className="flex items-center space-x-1.5 text-amber-400 font-bold text-xs uppercase font-mono border-b border-white/10 pb-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span>Mandatory Staff Compliance Declarations</span>
                </div>

                <label className="flex items-start space-x-2.5 cursor-pointer text-xs text-zinc-300">
                  <input
                    type="checkbox"
                    checked={decls.sanitization}
                    onChange={(e) => setDecls({ ...decls, sanitization: e.target.checked })}
                    className="mt-0.5 rounded border-zinc-700 text-blue-600 focus:ring-blue-500 bg-zinc-950"
                  />
                  <span>I verify that my workspace, tills, tools or counter have been fully sanitized.</span>
                </label>

                <label className="flex items-start space-x-2.5 cursor-pointer text-xs text-zinc-300">
                  <input
                    type="checkbox"
                    checked={decls.fitForWork}
                    onChange={(e) => setDecls({ ...decls, fitForWork: e.target.checked })}
                    className="mt-0.5 rounded border-zinc-700 text-blue-600 focus:ring-blue-500 bg-zinc-950"
                  />
                  <span>I declare I meet all hygienic and physical fit-for-work policy standards today.</span>
                </label>

                <label className="flex items-start space-x-2.5 cursor-pointer text-xs text-zinc-300">
                  <input
                    type="checkbox"
                    checked={decls.uniformStandard}
                    onChange={(e) => setDecls({ ...decls, uniformStandard: e.target.checked })}
                    className="mt-0.5 rounded border-zinc-700 text-blue-600 focus:ring-blue-500 bg-zinc-950"
                  />
                  <span>I am fully dressed in correct Kahawa West Uniform with visible Staff ID badges.</span>
                </label>
              </div>
            )}

            {/* Clock action button */}
            <div className="pt-2">
              {isClockedIn ? (
                <button
                  onClick={() => handleClockAction("CLOCK_OUT")}
                  disabled={loading}
                  className="w-full py-3 bg-red-600 hover:bg-red-750 text-white rounded-xl font-bold font-sans shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 text-sm disabled:opacity-50"
                >
                  <Square className="w-4 h-4 fill-white shrink-0 animate-pulse" />
                  <span>Clock Out / Punch Finish Card</span>
                </button>
              ) : (
                <button
                  onClick={() => handleClockAction("CLOCK_IN")}
                  disabled={loading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold font-sans shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 text-sm disabled:opacity-50 shadow-blue-500/10"
                >
                  <Play className="w-4 h-4 fill-white shrink-0" />
                  <span>Clock In / Punch Start Card</span>
                </button>
              )}
            </div>

          </div>
        </div>

      </div>

      {/* RIGHT COLUMN: Real-Time Historical Checklist / Shifts Today */}
      <div className="lg:col-span-5 space-y-6">
        
        {/* Personal Stats Dashboard */}
        <div className="bg-gradient-to-br from-blue-700/20 via-[#121214] to-indigo-950/40 border border-blue-500/20 rounded-2xl shadow-xl overflow-hidden p-6 relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl transform translate-x-4 -translate-y-4" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl transform -translate-x-4 translate-y-4" />
          
          <div className="relative">
            <h4 className="text-xs uppercase font-mono tracking-widest text-blue-400 font-bold mb-4 flex items-center space-x-2.5">
              <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
              <span>Shift Summary Today</span>
            </h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#18181C] p-3.5 rounded-xl border border-white/5">
                <p className="text-[10px] text-zinc-400 uppercase font-mono">Shift Period</p>
                <p className="text-xs font-bold leading-tight mt-0.5 truncate text-white">{user.shift.split(" ")[0]} Shift</p>
                <span className="text-[9px] text-blue-400 font-mono mt-1 block">Full Week Schedule</span>
              </div>

              <div className="bg-[#18181C] p-3.5 rounded-xl border border-white/5">
                <p className="text-[10px] text-zinc-400 uppercase font-mono">Records Today</p>
                <p className="text-base font-bold leading-tight mt-0.5 text-white">{history.length} Punches</p>
                <span className="text-[9px] text-blue-400 font-mono mt-1 block">Shift register count</span>
              </div>
            </div>

            {lastAction && (
              <div className="mt-4 pt-3 border-t border-white/10 flex justify-between items-center text-xs">
                <div>
                  <span className="text-zinc-400">Last event: </span>
                  <span className="font-mono bg-blue-900/30 text-blue-300 border border-blue-500/20 px-1.5 py-0.5 rounded font-bold">
                    {lastAction.actionType === "CLOCK_IN" ? "Clock-In" : "Clock-Out"}
                  </span>
                </div>
                <span className="text-zinc-300 font-mono">{new Date(lastAction.timestamp).toLocaleTimeString([], {hour: "2-digit", minute:"2-digit"})}</span>
              </div>
            )}
          </div>
        </div>

        {/* Employee Action History Log */}
        <div className="bg-[#121214] rounded-2xl shadow-xl border border-white/10 p-6">
          <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span className="bg-blue-600/10 p-1 rounded-lg text-blue-400 shrink-0">
                <Clock className="w-4 h-4" />
              </span>
              <span>Your Attendance Logs Today</span>
            </h3>
            <button
              onClick={fetchStatus}
              className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/5 rounded-lg transition-all"
              title="Refresh attendance details"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flow-root relative">
            {history.length === 0 ? (
              <div className="text-center py-10">
                <div className="w-10 h-10 bg-white/5 text-zinc-550 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckSquare className="w-5 h-5 text-zinc-500" />
                </div>
                <p className="text-xs text-zinc-400">No shift logs found for today.</p>
                <p className="text-[10px] text-zinc-550 mt-1">Accept compliance and punch in above to create daily history.</p>
              </div>
            ) : (
              <ul className="-mb-8">
                {history.map((act, actIdx) => (
                  <li key={act.id}>
                    <div className="relative pb-8">
                      {actIdx !== history.length - 1 ? (
                        <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-white/10" aria-hidden="true" />
                      ) : null}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-4 ring-[#121214] font-mono text-[10px] font-bold ${
                            act.actionType === "CLOCK_IN" 
                              ? "bg-emerald-500/20 text-emerald-300"
                              : "bg-amber-500/20 text-amber-300"
                          }`}>
                            {act.actionType === "CLOCK_IN" ? "IN" : "OUT"}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0 pt-1.5">
                          <div className="flex justify-between items-center">
                            <p className="text-xs font-bold text-white">
                              {act.actionType === "CLOCK_IN" ? "Shift Punch-In" : "Shift Punch-Out"}
                            </p>
                            <span className="text-[10px] text-zinc-550 font-mono">
                              {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                            </span>
                          </div>
                          
                          <div className="mt-1 text-xs text-zinc-400 space-y-1">
                            <div className="flex items-center space-x-1 text-[11px] text-blue-400 font-mono">
                              <MapPin className="w-3 h-3" />
                              <span>{act.location}</span>
                            </div>
                            
                            {act.notes && (
                              <p className="p-2 bg-[#161619] border border-white/5 rounded text-[11px] italic text-zinc-300 mt-1">
                                &ldquo;{act.notes}&rdquo;
                              </p>
                            )}

                            {/* Compliance checks summary */}
                            <div className="pt-1 flex items-center space-x-1.5 text-[10px]">
                              <span className={`px-1.5 py-0.5 rounded font-bold uppercase ${
                                act.complianceStatus === "compliant" 
                                  ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                  : "bg-red-500/10 text-red-400 border border-red-500/20"
                              }`}>
                                {act.complianceStatus}
                              </span>

                              {act.complianceFlags.length > 0 && (
                                <span className="text-red-400 font-mono">
                                  ({act.complianceFlags.join(", ")})
                                </span>
                              )}
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
