/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { User } from "../types";
import { ClockPanel } from "./ClockPanel";
import { BookOpen, Sparkles, Award, MapPin, ListChecks, HeartHandshake } from "lucide-react";

interface EmployeePortalProps {
  user: User;
  token: string;
  onActivityLogged: () => void;
}

export function EmployeePortal({ user, token, onActivityLogged }: EmployeePortalProps) {
  return (
    <div className="space-y-6">
      
      {/* Top Welcome Card */}
      <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 overflow-hidden relative p-6">
        <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/5 rounded-full blur-3xl transform translate-x-8 -translate-y-8" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative">
          <div className="flex items-center space-x-4">
            <div className="h-14 w-14 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-bold font-mono text-xl shadow-lg border border-blue-500/30">
              {user.fullName.split(" ").map(n => n[0]).join("")}
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h2 className="text-xl font-bold text-white font-sans">{user.fullName}</h2>
                <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-mono text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Staff Card Active
                </span>
                <Award className="w-4.5 h-4.5 text-yellow-500" />
              </div>
              <p className="text-xs text-zinc-400 font-mono">
                Department: <span className="font-semibold text-blue-400">{user.department}</span> | Employee ID: <span className="font-semibold text-zinc-300">{user.id}</span>
              </p>
            </div>
          </div>

          <div className="bg-[#1A1A1E] p-3.5 rounded-xl border border-white/5 text-zinc-350 text-xs max-w-xs self-start md:self-center">
            <div className="flex items-center space-x-1 font-bold text-[11px] uppercase font-mono mb-0.5 text-blue-400">
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Kahawa West Motto</span>
            </div>
            <p className="italic text-zinc-300 font-medium">
              &ldquo;Premium customer care daily, with efficient registers and tidy shelves!&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Embedded Clock Punches */}
      <ClockPanel user={user} token={token} onActivityLogged={onActivityLogged} />

      {/* Bottom Store Policy Reference / Principles Block */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        
        {/* Compliance Guidelines */}
        <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 p-5">
          <h4 className="text-xs font-bold uppercase tracking-widest font-mono text-blue-450 flex items-center space-x-1.5 border-b border-white/10 pb-2 mb-3">
            <BookOpen className="w-4 h-4 text-blue-450" />
            <span className="text-blue-400">Store Attendance Regulations</span>
          </h4>
          
          <ul className="space-y-2 text-xs text-zinc-300">
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span><strong className="text-white">Shift Arrival:</strong> Clock in at least 5 minutes prior to scheduled shift start to count as compliant.</span>
            </li>
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span><strong className="text-white">Register Uniform:</strong> Caps, branded apron, and safety shoes are mandatory at checkouts and bakery docks.</span>
            </li>
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span><strong className="text-white">Overtime Checks:</strong> Shift lengths exceeding 8 hours must be signed off by the central floor manager.</span>
            </li>
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span><strong className="text-white">Safety Rules:</strong> All food prep areas (Produce & Bakery) require hourly sanitization with registered checklists.</span>
            </li>
          </ul>
        </div>

        {/* Customer Care Goals */}
        <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 p-5">
          <h4 className="text-xs font-bold uppercase tracking-widest font-mono text-blue-450 flex items-center space-x-1.5 border-b border-white/10 pb-2 mb-3">
            <ListChecks className="w-4 h-4 text-blue-450" />
            <span className="text-blue-400">Customer Service SOP</span>
          </h4>
          
          <ul className="space-y-2 text-xs text-zinc-300">
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span>Always greet customers with warm Kenyan hospitality (&ldquo;Habari yako, Karibu Kahawa West supermarket!&rdquo;)</span>
            </li>
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span>Pack grocery bags with weight separation (heavy at the bottom, fresh vegetables on top).</span>
            </li>
            <li className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <span>Promote our Supermarket loyalty card program on transaction payouts.</span>
            </li>
          </ul>
        </div>

      </div>

    </div>
  );
}
