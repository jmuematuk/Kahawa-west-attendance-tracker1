/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { User, LogIn, Key, Briefcase, Clock, ShieldAlert, Sparkles, Building, UserPlus } from "lucide-react";
import { Department, ShiftType } from "../types";

interface LoginRegisterProps {
  onLoginSuccess: (user: any, token: string) => void;
}

export function LoginRegister({ onLoginSuccess }: LoginRegisterProps) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Common fields
  const [username, setUsername] = useState(""); // Also matches Employee ID (National ID)
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  // Employee-only fields
  const [department, setDepartment] = useState<Department>(Department.CASHIER);
  const [shift, setShift] = useState<ShiftType>(ShiftType.MORNING);

  // Admin-only fields
  const [adminCode, setAdminCode] = useState("");

  const [loading, setLoading] = useState(false);

  // Quick Account Help
  const quickLogin = async (role: "employee" | "admin") => {
    setLoading(true);
    setError(null);
    try {
      const payload = role === "employee" 
        ? { id: "KW-8849-CS", password: "password123" }
        : { username: "kahawa_manager", password: "manager123" };
      
      const endpoint = role === "employee" ? "/api/auth/employee/login" : "/api/auth/admin/login";
      
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to log in");
      
      setSuccess("Logged in successfully!");
      setTimeout(() => {
        onLoginSuccess(data.user, data.token);
      }, 500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!username || !password) {
      setError("Please fill in all required fields.");
      return;
    }

    if (isRegistering && !fullName) {
      setError("Full name is required for registration.");
      return;
    }

    setLoading(true);

    try {
      if (isRegistering) {
        // REGISTRATION
        const endpoint = isAdmin ? "/api/auth/admin/register" : "/api/auth/employee/register";
        const body = isAdmin
          ? { username, fullName, password, adminCode }
          : { id: username, fullName, department, shift, password };

        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Registration failed");

        setSuccess("Registration successful! You can now log in.");
        setIsRegistering(false);
        // Autofill password but reset other fields
        setFullName("");
        setAdminCode("");
      } else {
        // LOGIN
        const endpoint = isAdmin ? "/api/auth/admin/login" : "/api/auth/employee/login";
        const body = isAdmin
          ? { username, password }
          : { id: username, password };

        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Login failed");

        setSuccess(`Welcome back, ${data.user.fullName}!`);
        setTimeout(() => {
          onLoginSuccess(data.user, data.token);
        }, 800);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-[#121214] rounded-2.5xl shadow-2xl border border-white/10 overflow-hidden">
        {/* Header Branding */}
        <div className="bg-gradient-to-br from-blue-700 to-indigo-900 text-white p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl transform translate-x-8 -translate-y-8" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl transform -translate-x-6 translate-y-6" />
          
          <div className="relative flex items-center space-x-3">
            <div className="bg-blue-600/30 p-2.5 rounded-xl border border-blue-400/30">
              <Building className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-blue-300 font-semibold font-mono">
                Kahawa West Supermarket
              </p>
              <h2 className="text-xl font-bold tracking-tight text-white font-sans">
                Shift Lock Gateway
              </h2>
            </div>
          </div>
        </div>

        {/* Auth Role Selector Tabs */}
        <div className="flex border-b border-white/10 bg-[#161619]">
          <button
            onClick={() => {
              setIsAdmin(false);
              setIsRegistering(false);
              setError(null);
            }}
            className={`flex-1 py-3 text-center text-sm font-medium font-sans border-b-2 transition-all ${
              !isAdmin
                ? "border-blue-500 text-white bg-white/5 shadow-sm"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Employee Attendance
          </button>
          <button
            onClick={() => {
              setIsAdmin(true);
              setIsRegistering(false);
              setError(null);
            }}
            className={`flex-1 py-3 text-center text-sm font-medium font-sans border-b-2 transition-all ${
              isAdmin
                ? "border-blue-500 text-white bg-white/5 shadow-sm"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Manager Registry
          </button>
        </div>

        {/* Auth Forms */}
        <div className="p-6">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-white font-sans">
              {isRegistering ? "Create New Profile" : "Secure Gate Sign-In"}
            </h3>
            <p className="text-xs text-zinc-400">
              {isRegistering
                ? `Register a new ${isAdmin ? "administrator" : "staff member"} account.`
                : `Enter credentials to access the ${isAdmin ? "management suite" : "employee register"} panel.`}
            </p>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-red-950/40 text-red-300 border border-red-900/30 rounded-lg text-xs flex items-start space-x-2"
            >
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </motion.div>
          )}

          {success && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-emerald-950/40 text-emerald-300 border border-emerald-900/30 rounded-lg text-xs flex items-center space-x-2"
            >
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Registration only: Full Name */}
            {isRegistering && (
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Grace Mwangi"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white bg-black/20 placeholder-zinc-500"
                  />
                </div>
              </div>
            )}

            {/* Login Credential ID */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                {isAdmin ? "Admin Username" : "Employee ID or ID Card Number"}
              </label>
              <div className="relative">
                <LogIn className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  required
                  placeholder={isAdmin ? "e.g. supervisor_max" : "e.g. KW-8849-CS"}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white font-mono bg-black/20 placeholder-zinc-500"
                />
              </div>
            </div>

            {/* Employee-only specific configuration */}
            {!isAdmin && isRegistering && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Supermarket Section
                  </label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <select
                      value={department}
                      onChange={(e) => setDepartment(e.target.value as Department)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-white/10 rounded-lg bg-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
                    >
                      {Object.values(Department).map((dept) => (
                        <option key={dept} value={dept}>
                          {dept}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Scheduled Shift Block
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <select
                      value={shift}
                      onChange={(e) => setShift(e.target.value as ShiftType)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-white/10 rounded-lg bg-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
                    >
                      {Object.values(ShiftType).map((sh) => (
                        <option key={sh} value={sh}>
                          {sh}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Admin-only specific configuration */}
            {isAdmin && isRegistering && (
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1 flex justify-between items-center">
                  <span>Authorized Key Ring</span>
                  <span className="text-[10px] text-zinc-400 lowercase font-mono">default is admin123</span>
                </label>
                <div className="relative">
                  <Key className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    type="password"
                    required
                    placeholder="access token, e.g. admin123"
                    value={adminCode}
                    onChange={(e) => setAdminCode(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white bg-black/20 placeholder-zinc-500"
                  />
                </div>
              </div>
            )}

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Password
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white bg-black/20 placeholder-zinc-500"
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold shadow-md transition-all flex items-center justify-center space-x-2 disabled:bg-blue-850/50"
            >
              {loading ? (
                <span className="animate-pulse">Authorizing Gate Access...</span>
              ) : (
                <>
                  <span>{isRegistering ? "Submit Registration" : "Slide Card & Auth"}</span>
                </>
              )}
            </button>
          </form>

          {/* Toggle register vs login */}
          <div className="mt-4 text-center">
            <button
              onClick={() => {
                setIsRegistering(!isRegistering);
                setError(null);
                setSuccess(null);
              }}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold underline flex items-center justify-center mx-auto space-x-1"
            >
              <UserPlus className="w-3.5 h-3.5 inline mr-1" />
              <span>
                {isRegistering ? "Back to Login Portal" : "Need to register for shift logs?"}
              </span>
            </button>
          </div>

          {/* Quick Access Helper Bar (Devs/Evaluators Delight) */}
          <div className="mt-6 pt-5 border-t border-white/10">
            <p className="text-[11px] font-mono font-semibold text-blue-400 uppercase tracking-widest text-center mb-3">
              🔓 Quick Demo Portals
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => quickLogin("employee")}
                disabled={loading}
                className="p-3 bg-zinc-900 hover:bg-zinc-850 border border-white/10 rounded-lg text-left transition-all"
              >
                <div className="flex items-center space-x-1.5 text-zinc-100 font-semibold text-xs font-sans">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  <span>Cashier Card</span>
                </div>
                <p className="text-[10px] text-zinc-400 font-mono mt-1">
                  ID: KW-8849-CS
                </p>
              </button>

              <button
                type="button"
                onClick={() => quickLogin("admin")}
                disabled={loading}
                className="p-3 bg-zinc-900 hover:bg-zinc-850 border border-white/10 rounded-lg text-left transition-all"
              >
                <div className="flex items-center space-x-1.5 text-blue-400 font-semibold text-xs font-sans">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                  <span>Admin Panel</span>
                </div>
                <p className="text-[10px] text-blue-300/80 font-mono mt-1">
                  User: kahawa_manager
                </p>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
