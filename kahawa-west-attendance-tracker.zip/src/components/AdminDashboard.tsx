/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  Users, Clock, AlertTriangle, ShieldCheck, Search, Filter, RefreshCw, 
  Download, FileSpreadsheet, Building, AlertCircle, PlayCircle, LogIn, CheckCircle 
} from "lucide-react";
import { Department, ClockAction, User } from "../types";

interface AdminDashboardProps {
  adminUser: any;
  token: string;
  clockInTrigger: number; // Increment triggers a reload of logs
}

export function AdminDashboard({ adminUser, token, clockInTrigger }: AdminDashboardProps) {
  const [logs, setLogs] = useState<ClockAction[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDept, setSelectedDept] = useState<string>("ALL");
  const [selectedComp, setSelectedComp] = useState<string>("ALL");
  const [showSimulations, setShowSimulations] = useState(true);

  // Fetch admin states
  const fetchData = async () => {
    setLoading(true);
    try {
      const logsRes = await fetch("/api/admin/logs", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const logsData = await logsRes.json();

      const usersRes = await fetch("/api/admin/users", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const usersData = await usersRes.json();

      if (logsRes.ok && usersRes.ok) {
        setLogs(logsData.logs || []);
        setAllUsers(usersData.users || []);
      }
    } catch (err) {
      console.error("Error fetching admin stats:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token, clockInTrigger]);

  // Trigger a store simulation event for demo purposes block
  const triggerSimulation = async (simType: string) => {
    setStatusMessage(null);
    try {
      const res = await fetch("/api/admin/simulate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ simType })
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMessage(`✅ Simulation Triggered: ${data.message}`);
        fetchData();
      } else {
        throw new Error(data.message);
      }
    } catch (err: any) {
      setStatusMessage(`❌ Simulation Failed: ${err.message}`);
    }
  };

  // Reset demo accounts & logs to defaults
  const resetDatabase = async () => {
    setStatusMessage(null);
    try {
      const res = await fetch("/api/admin/reset", {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        setStatusMessage("✅ Database state reset to default pre-seeded logs.");
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // CSV Export Mechanism
  const downloadCSV = () => {
    if (filteredLogs.length === 0) return;
    
    // Header Row
    const headers = ["ID", "Timestamp", "Employee Name", "Department", "ActionType", "Station Location", "Compliance Status", "Compliance Flags", "Notes"];
    
    const rows = filteredLogs.map(l => [
      l.id,
      new Date(l.timestamp).toLocaleString("en-US", { hour12: false }),
      l.userName,
      l.userDepartment,
      l.actionType,
      l.location,
      l.complianceStatus,
      l.complianceFlags.join(" & "),
      (l.notes || "").replace(/"/g, '""')
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.map(val => `"${val}"`).join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Kahawa_West_Shift_Compliance_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtering Logic
  const filteredLogs = logs.filter(l => {
    const matchesSearch = 
      l.userName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      l.userId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (l.notes && l.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
      l.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDept = selectedDept === "ALL" || l.userDepartment === selectedDept;
    
    const matchesComp = selectedComp === "ALL" || 
      (selectedComp === "COMPLIANT" && l.complianceStatus === "compliant") || 
      (selectedComp === "NON_COMPLIANT" && l.complianceStatus === "non-compliant");

    return matchesSearch && matchesDept && matchesComp;
  });

  // Calculate Metrics
  const totalEmployees = allUsers.filter(u => u.role === "employee").length;
  // Currently clocked in = those whose last action in today is a CLOCK_IN
  // Let's compute this dynamically from current DB state of active employees
  const currentlyClockedInList = allUsers.filter(u => u.role === "employee" && u.isActive === true);
  const currentlyClockedInCount = currentlyClockedInList.length;

  // Present Today
  const uniqueUsersToday = new Set(logs.map(l => l.userId));
  const totalPresentToday = uniqueUsersToday.size;

  // Compliance metrics
  const infractionsCount = logs.filter(l => l.complianceStatus === "non-compliant").length;
  const totalAssessed = logs.length;
  const complianceRate = totalAssessed > 0 
    ? Math.round(((totalAssessed - infractionsCount) / totalAssessed) * 100) 
    : 100;

  // Summarize staffing count by Department
  const deptStaffCount = Object.values(Department).reduce((acc, dept) => {
    const onFloor = currentlyClockedInList.filter(u => u.department === dept).length;
    acc[dept] = onFloor;
    return acc;
  }, {} as Record<string, number>);

  // Detect critical staffing vacancies (Supermarket Floor Policy Coverage)
  const isCashierEmpty = deptStaffCount[Department.CASHIER] === 0;
  const isSecurityEmpty = deptStaffCount[Department.SECURITY] === 0;
  const isProduceEmpty = deptStaffCount[Department.PRODUCE] === 0;

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Control Panel */}
      <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="bg-blue-600 text-white p-3 rounded-2xl shadow-lg shadow-blue-500/10">
            <Building className="w-7 h-7 text-blue-100" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white leading-tight">Kahawa West Operations Control</h2>
            <p className="text-xs text-zinc-400 font-mono mt-0.5">
              Logged in: <span className="font-bold text-blue-400">{adminUser.fullName}</span> (Senior Supervisor)
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={fetchData}
            disabled={loading}
            className="px-3.5 py-2 bg-white/5 hover:bg-white/10 text-blue-400 border border-white/10 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Sync Register</span>
          </button>
          
          <button
            onClick={resetDatabase}
            className="px-3.5 py-2 bg-red-955/10 hover:bg-red-950/30 text-red-400 border border-red-900/20 rounded-lg text-xs font-semibold transition-all"
            title="Resets database logs to pristine default state"
          >
            Reset Logs
          </button>
        </div>
      </div>

      {statusMessage && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-3.5 rounded-xl text-xs font-medium border ${
            statusMessage.includes("❌") ? "bg-red-950/40 text-red-300 border-red-900/30" : "bg-emerald-955/40 text-emerald-300 border-emerald-900/30"
          }`}
        >
          {statusMessage}
        </motion.div>
      )}

      {/* Real-time Dashboard KPIs grids */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* KPI: Staff Clocked-In */}
        <div className="bg-[#121214] p-5 rounded-2xl shadow-2xl border border-white/10">
          <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-zinc-450 font-bold uppercase tracking-wider font-mono">Present Now</span>
            <Users className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-3xl font-mono font-bold text-white">{currentlyClockedInCount}</p>
          <p className="text-[10px] text-zinc-400 mt-1 font-sans">Inside Kahawa West Supermarket</p>
        </div>

        {/* KPI: Total Present Today */}
        <div className="bg-[#121214] p-5 rounded-2xl shadow-2xl border border-white/10">
          <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-zinc-450 font-bold uppercase tracking-wider font-mono">Total Roster</span>
            <Building className="w-5 h-5 text-indigo-400" />
          </div>
          <p className="text-3xl font-mono font-bold text-white">{totalEmployees}</p>
          <p className="text-[10px] text-zinc-400 mt-1">Total registered accounts</p>
        </div>

        {/* KPI: Active Today */}
        <div className="bg-[#121214] p-5 rounded-2xl shadow-2xl border border-white/10">
          <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-zinc-450 font-bold uppercase tracking-wider font-mono">Active Today</span>
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-3xl font-mono font-bold text-white">{totalPresentToday}</p>
          <p className="text-[10px] text-zinc-400 mt-1 font-sans">Unique workers punched</p>
        </div>

        {/* KPI: Compliance score */}
        <div className="bg-[#121214] p-5 rounded-2xl shadow-2xl border border-white/10">
          <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-zinc-450 font-bold uppercase tracking-wider font-mono">Shift Compliance</span>
            <ShieldCheck className={`w-5 h-5 ${complianceRate > 85 ? 'text-emerald-400' : 'text-amber-400'}`} />
          </div>
          <p className="text-3xl font-mono font-bold text-white">{complianceRate}%</p>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
            <div 
              style={{ width: `${complianceRate}%` }} 
              className={`h-full rounded-full ${complianceRate > 85 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
            />
          </div>
        </div>

        {/* KPI: Active warning infractions count */}
        <div className="bg-[#121214] p-5 rounded-2xl shadow-2xl border border-white/10 col-span-2 lg:col-span-1">
          <div className="flex justify-between items-start mb-2">
            <span className="text-xs text-red-400 font-bold uppercase tracking-wider font-mono">Policy Flags</span>
            <AlertTriangle className="w-5 h-5 text-red-500" />
          </div>
          <p className="text-3xl font-mono font-bold text-red-400">{infractionsCount}</p>
          <p className="text-[10px] text-red-400/80 mt-1 font-bold">Compliance occurrences logged</p>
        </div>

      </div>

      {/* Simulated events triggers & Store Vacancies Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Flag Warnings / Operations Vacuum Risks */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 p-5">
            <h4 className="text-xs uppercase font-mono font-bold text-zinc-405 mb-3 tracking-widest flex items-center justify-between">
              <span>Department floor staffing</span>
              <span className="text-[10px] text-blue-400 lowercase font-sans">Active check</span>
            </h4>
            
            <div className="space-y-2.5">
              {Object.entries(deptStaffCount).map(([dept, count]) => (
                <div key={dept} className="flex justify-between items-center text-xs text-zinc-300">
                  <span className="font-medium">{dept}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-zinc-805 h-2 rounded-full overflow-hidden">
                      <div 
                        style={{ width: `${Math.min((count / 3) * 100, 100)}%` }} 
                        className={`h-full rounded-full ${count > 0 ? 'bg-emerald-500' : 'bg-red-500/50'}`} 
                      />
                    </div>
                    <span className={`w-8 font-mono text-right font-bold ${count > 0 ? 'text-zinc-200' : 'text-red-405'}`}>
                      {count} on
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Crucial Store Floor Warnings */}
            {(isCashierEmpty || isSecurityEmpty) && (
              <div className="mt-4 p-3 bg-red-950/40 rounded-xl border border-red-900/30 text-xs text-red-300 space-y-1.5">
                <div className="flex items-center space-x-1.5 font-bold">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>CRITICAL STAFFING POLICY BREACH</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-zinc-300">
                  {isCashierEmpty && <li><strong>Checkout Counters unmanned:</strong> No Cashier was detected on duty! Minimum occupancy is 1.</li>}
                  {isSecurityEmpty && <li><strong>Security vacuum:</strong> No Security patrol detected! Emergency security procedure violation.</li>}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Real-time Simulator control block (for developer demo presentation) */}
        <div className="lg:col-span-7">
          <div className="bg-[#121214] border border-white/10 rounded-2xl p-5 relative overflow-hidden h-full flex flex-col justify-between">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-xl" />
            
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <PlayCircle className="w-5 h-5 text-blue-400" />
                <h4 className="text-sm font-bold font-sans text-white">Manager Demo Simulation sandbox</h4>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Evaluating the system? Run these actions to seed dummy clock activities instantly. You will watch how the charts, graphs, compliance infractions, and audit trails change real-time!
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5 mt-4">
              <button
                onClick={() => triggerSimulation("COMPLIANT")}
                className="py-2.5 px-3 bg-black/30 hover:bg-white/5 border border-white/10 rounded-xl text-left text-xs transition-colors space-y-1"
              >
                <div className="font-bold text-emerald-400 font-sans">✅ Safe Punch-In</div>
                <p className="text-[10px] text-zinc-400">Grace Mwangi signs in compliant to till #2.</p>
              </button>

              <button
                onClick={() => triggerSimulation("LATE")}
                className="py-2.5 px-3 bg-zinc-900 hover:bg-[#1A1A1E] border border-white/10 rounded-xl text-left text-xs transition-colors space-y-1"
              >
                <div className="font-bold text-amber-400 font-sans">⏰ Late Punch-In</div>
                <p className="text-[10px] text-zinc-500">John Kiprop clock-in gets flagged as Late (Late shift).</p>
              </button>

              <button
                onClick={() => triggerSimulation("OVERTIME")}
                className="py-2.5 px-3 bg-red-950/20 hover:bg-red-950/30 border border-red-900/30 rounded-xl text-left text-xs transition-colors space-y-1 col-span-2 md:col-span-1"
              >
                <div className="font-bold text-red-400 font-sans text-light">⚠️ Overtime Punch</div>
                <p className="text-[10px] text-red-300">Simulates working an extensive shift exceeding limits.</p>
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Main logs list & Search Filter console */}
      <div className="bg-[#121214] rounded-2xl shadow-2xl border border-white/10 overflow-hidden">
        
        {/* Search, filters controls */}
        <div className="p-6 bg-[#161619] border-b border-white/10">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            
            {/* Title / exports */}
            <div>
              <h3 className="text-base font-bold text-white">Shift Gate Activity Registry</h3>
              <p className="text-xs text-zinc-450 font-mono mt-0.5">Showing {filteredLogs.length} of {logs.length} transactions</p>
            </div>

            {/* Search inputs */}
            <div className="flex flex-wrap items-center gap-3">
              
              {/* Search Bar */}
              <div className="relative text-xs w-full sm:w-56">
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-zinc-550" />
                <input
                  type="text"
                  placeholder="Filter name, ID, notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 w-full border border-white/10 rounded-lg text-xs bg-zinc-900 text-white focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-transparent"
                />
              </div>

              {/* Department Dropdown */}
              <div className="relative text-xs">
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="px-2 py-1.5 bg-zinc-900 border border-white/10 rounded-lg text-xs text-zinc-300 focus:outline-none focus:ring-1 focus:ring-blue-650"
                >
                  <option value="ALL">All Sections</option>
                  {Object.values(Department).map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              {/* Compliance Filter */}
              <div className="relative text-xs">
                <select
                  value={selectedComp}
                  onChange={(e) => setSelectedComp(e.target.value)}
                  className="px-2 py-1.5 bg-zinc-900 border border-white/10 rounded-lg text-xs text-zinc-300 focus:outline-none focus:ring-1 focus:ring-blue-650"
                >
                  <option value="ALL">All Regulations</option>
                  <option value="COMPLIANT">✅ Pure Compliant</option>
                  <option value="NON_COMPLIANT">⚠️ Policy Infractions</option>
                </select>
              </div>

              <button
                onClick={downloadCSV}
                disabled={filteredLogs.length === 0}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all disabled:opacity-40"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>

            </div>
          </div>
        </div>

        {/* Desktop Table of transactions */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-900 text-white border-b border-white/10 font-semibold text-xs font-mono uppercase tracking-wider">
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Employee Details</th>
                <th className="py-3.5 px-4">Department</th>
                <th className="py-3.5 px-4">Punch Type</th>
                <th className="py-3.5 px-4">Station Location</th>
                <th className="py-3.5 px-4 text-center">Policy Status</th>
                <th className="py-3.5 px-4">Notes & Warnings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs text-zinc-300">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-zinc-500 bg-black/10">
                    No registrations activity found matching your select parameters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((l) => (
                  <tr key={l.id} className="hover:bg-white/5 transition-all text-zinc-350">
                    
                    {/* Timestamp */}
                    <td className="py-3.5 px-4 font-mono text-zinc-500 whitespace-nowrap">
                      {new Date(l.timestamp).toLocaleString("en-US", {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                        hour12: false
                      })}
                    </td>

                    {/* User */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-bold text-white">{l.userName}</div>
                      <div className="font-mono text-[10px] text-zinc-550">ID: {l.userId}</div>
                    </td>

                    {/* Department */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-blue-400 font-semibold">
                      {l.userDepartment}
                    </td>

                    {/* Punch Action */}
                    <td className="py-3.5 px-4 whitespace-nowrap font-bold">
                      <span className={`px-2 py-0.5 rounded font-mono text-[11px] border ${
                        l.actionType === "CLOCK_IN" 
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                          : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                      }`}>
                        {l.actionType === "CLOCK_IN" ? "📥 Checked In" : "📤 Checked Out"}
                      </span>
                    </td>

                    {/* Station Location */}
                    <td className="py-3.5 px-4 font-mono font-medium text-zinc-300 whitespace-nowrap">
                      {l.location}
                    </td>

                    {/* Compliance Indicator */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-center">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border ${
                        l.complianceStatus === "compliant"
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                          : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                      }`}>
                        {l.complianceStatus === "compliant" ? "Compliant" : "Infraction"}
                      </span>
                    </td>

                    {/* Notes & Flags breakdown */}
                    <td className="py-3.5 px-4 min-w-[200px]">
                      <div className="space-y-1">
                        {l.complianceFlags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {l.complianceFlags.map(f => (
                              <span key={f} className="bg-red-950/40 text-red-400 border border-red-900/40 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase shrink-0">
                                {f}
                              </span>
                            ))}
                          </div>
                        )}
                        {l.notes ? (
                          <p className="text-[11px] text-zinc-400 italic truncate max-w-[250px]" title={l.notes}>
                            &ldquo;{l.notes}&rdquo;
                          </p>
                        ) : (
                          <span className="text-zinc-600 italic text-[10px]">No shift annotations.</span>
                        )}
                      </div>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
