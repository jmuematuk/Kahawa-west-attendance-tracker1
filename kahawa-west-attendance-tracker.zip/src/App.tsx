/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from "react";
import { 
  Building, LogOut, Clock, ShieldCheck, User as UserIcon, HelpCircle, AlertOctagon 
} from "lucide-react";
import { User } from "./types";
import { LoginRegister } from "./components/LoginRegister";
import { EmployeePortal } from "./components/EmployeePortal";
import { AdminDashboard } from "./components/AdminDashboard";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string>("");
  const [clockInTrigger, setClockInTrigger] = useState<number>(0);

  // Restore session from localStorage on load
  useEffect(() => {
    const savedUser = localStorage.getItem("kahawa_user");
    const savedToken = localStorage.getItem("kahawa_token");
    if (savedUser && savedToken) {
      try {
        setUser(JSON.parse(savedUser));
        setToken(savedToken);
      } catch (err) {
        console.error("Failed to restore session", err);
        localStorage.removeItem("kahawa_user");
        localStorage.removeItem("kahawa_token");
      }
    }
  }, []);

  const handleLoginSuccess = (loggedInUser: User, sessionToken: string) => {
    setUser(loggedInUser);
    setToken(sessionToken);
    localStorage.setItem("kahawa_user", JSON.stringify(loggedInUser));
    localStorage.setItem("kahawa_token", sessionToken);
  };

  const handleLogout = () => {
    setUser(null);
    setToken("");
    localStorage.removeItem("kahawa_user");
    localStorage.removeItem("kahawa_token");
  };

  // Real-time synchronization callback across active cards
  const handleActivityLogged = () => {
    setClockInTrigger((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#070708] text-zinc-100 flex flex-col font-sans selection:bg-blue-600/30 selection:text-white">
      
      {/* Dynamic Navigation Header */}
      <header className="sticky top-0 z-30 bg-[#0F0F11]/90 border-b border-white/10 shadow-lg backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo Branding */}
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 text-white p-2 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/10">
              <Building className="w-5 h-5 text-blue-100" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-extrabold text-white tracking-tight text-sm font-sans">
                  KAHAWA WEST
                </span>
                <span className="bg-blue-600/20 text-blue-400 border border-blue-500/30 font-mono text-[9px] font-bold px-1.5 py-0.5 rounded tracking-wider">
                  SUPERMARKET
                </span>
              </div>
              <p className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">
                Attendance & Shift Auditor
              </p>
            </div>
          </div>

          {/* Active Status Header Bar */}
          {user && (
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-xs bg-white/5 border border-white/15 py-1.5 px-3 rounded-xl">
                {user.role === "admin" ? (
                  <>
                    <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse shrink-0" />
                    <span className="font-mono text-zinc-300 font-bold">Manager Mode: Active</span>
                  </>
                ) : (
                  <>
                    <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${user.isActive ? "bg-emerald-500 animate-ping" : "bg-zinc-550"}`} />
                    <span className="font-mono text-zinc-300 font-medium">
                      Status: <span className="font-bold text-white">{user.isActive ? "Clocked-In" : "Clocked-Out"}</span>
                    </span>
                  </>
                )}
              </div>

              {/* Logged user badge */}
              <div className="flex items-center space-x-2.5">
                <div className="text-right">
                  <p className="text-xs font-bold text-white">{user.fullName}</p>
                  <p className="text-[10px] text-zinc-400 font-mono text-right capitalize">{user.role}</p>
                </div>
                
                <button
                  onClick={handleLogout}
                  className="p-2 text-zinc-400 hover:text-red-400 hover:bg-white/5 border border-transparent hover:border-white/10 rounded-xl transition-all"
                  title="Secure logout session"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

        </div>
      </header>

      {/* Main Content Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:px-6 lg:px-8 py-8">
        
        {!user ? (
          /* Locked State Gateway */
          <div className="py-8 flex flex-col items-center justify-center">
            <LoginRegister onLoginSuccess={handleLoginSuccess} />
            
            {/* Compliance Info Banner */}
            <div className="mt-8 max-w-md w-full bg-[#121214] p-5 rounded-2xl border border-white/10 shadow-xl text-[11px] text-zinc-400 space-y-1.5">
              <div className="flex items-center space-x-1.5 font-bold text-blue-400">
                <ShieldCheck className="w-4 h-4 shrink-0 text-blue-400" />
                <span>STORE POLICY COMPLIANCE ENFORCED</span>
              </div>
              <p className="leading-relaxed text-zinc-400">
                This system automatically logs attendance, shifts, and timestamps. Infractions (such as unexcused lateness, health agreement bypass, or shift overtime violations) are tracked instantly for supervisory compliance auditing.
              </p>
            </div>
          </div>
        ) : (
          /* Authenticated Pages Router */
          <div>
            {user.role === "admin" ? (
              <AdminDashboard 
                adminUser={user} 
                token={token} 
                clockInTrigger={clockInTrigger} 
              />
            ) : (
              <EmployeePortal 
                user={user} 
                token={token} 
                onActivityLogged={handleActivityLogged} 
              />
            )}
          </div>
        )}

      </main>

      {/* Footer System Credits */}
      <footer className="bg-[#0F0F11] border-t border-white/10 py-6 text-center text-xs text-zinc-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <span>&copy; {new Date().getFullYear()} Kahawa West Supermarket. Gate Audit Terminal v2.4.</span>
          <div className="flex items-center space-x-3 text-[10px] text-zinc-500">
            <a href="#" className="hover:text-zinc-300 transition-colors">Legal Compliance</a>
            <span>•</span>
            <a href="#" className="hover:text-zinc-300 transition-colors">Shift Regulations</a>
            <span>•</span>
            <a href="#" className="hover:text-zinc-300 transition-colors">Support Desk</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
