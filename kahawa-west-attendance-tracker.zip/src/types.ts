/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Department {
  CASHIER = "Checkout / Cashiers",
  PRODUCE = "Fresh Produce & Bakery",
  INVENTORY = "Inventory & Shelving",
  SECURITY = "Security & Loss Prevention",
  CUSTOMER_SERVICE = "Customer Service & Desk",
  ADMIN = "Administration / Management"
}

export enum ShiftType {
  MORNING = "Morning Shift (06:00 - 14:00)",
  AFTERNOON = "Afternoon Shift (14:00 - 22:00)",
  NIGHT = "Night Shift (22:00 - 06:00)"
}

export interface User {
  id: string; // Employee ID or National ID
  fullName: string;
  department: Department;
  shift: ShiftType;
  role: "employee" | "admin";
  isActive: boolean;
  createdAt: string;
}

export interface ClockAction {
  id: string;
  userId: string;
  userName: string;
  userDepartment: Department;
  actionType: "CLOCK_IN" | "CLOCK_OUT";
  timestamp: string; // ISO String
  location: string; // Supermarket Station
  healthDeclarationAccepted: boolean;
  notes?: string;
  complianceChecked: boolean;
  complianceStatus: "compliant" | "non-compliant";
  complianceFlags: string[]; // e.g. "Late Attendance", "Unexcused Short Gap", "Extended Shift Overtime"
}

export interface RealtimeMetrics {
  totalRegistered: number;
  currentlyClockedIn: number;
  totalPresentToday: number;
  complianceRate: number; // Percentage
  infractionsCount: number;
}
